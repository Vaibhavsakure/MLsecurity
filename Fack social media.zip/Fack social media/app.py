import streamlit as st
import joblib

instagram_model = joblib.load("fake_account_detector.pkl")
twitter_model = joblib.load("twitter_bot_detector.pkl")

st.title("SocialGuard AI")
st.subheader("Multi-Platform Fake Account Detection")

platform = st.selectbox(
    "Select Social Media Platform",
    ["Instagram", "Twitter"]
)

if platform == "Instagram":

    st.header("Instagram Fake Account Detection")

    profile_pic = st.selectbox("Profile picture present?", [0,1])
    username_numbers = st.selectbox("Username contains many numbers?", [0,1])
    bio_present = st.selectbox("Bio present?", [0,1])

    posts = st.number_input("Number of posts", min_value=0)
    followers = st.number_input("Followers", min_value=0)
    follows = st.number_input("Following", min_value=0)

    if st.button("Analyze Instagram Account"):

        follower_following_ratio = followers / (follows + 1)
        posts_per_follower = posts / (followers + 1)

        has_description = bio_present
        has_fullname = 1

        profile_completeness = profile_pic + has_description + has_fullname

        features = [[
            profile_pic,
            0.7 if username_numbers == 1 else 0,
            1,
            0,
            0,
            bio_present,
            0,
            0,
            posts,
            followers,
            follows,
            follower_following_ratio,
            posts_per_follower,
            has_description,
            has_fullname,
            profile_completeness
        ]]

        prob = instagram_model.predict_proba(features)[0][1]

        st.write("Fake Probability:", round(prob,3))

elif platform == "Twitter":

    st.header("Twitter Bot Detection")

    statuses = st.number_input("Number of tweets")
    followers = st.number_input("Followers")
    friends = st.number_input("Friends")
    favourites = st.number_input("Favourites")
    listed = st.number_input("Listed count")

    verified = st.selectbox("Verified account?", [0,1])
    default_profile_image = st.selectbox("Default profile image?", [0,1])
    
    if st.button("Analyze Twitter Account"):

        features = [[
            statuses,
            followers,
            friends,
            favourites,
            listed,
            verified,
            default_profile_image
        ]]

        prob = twitter_model.predict_proba(features)[0][1]

        st.write("Bot Probability:", round(prob,3))